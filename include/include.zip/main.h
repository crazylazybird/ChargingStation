#pragma once
#include <Arduino.h>
#include <SoftwareSerial.h>
#include <map>
#include <vector>
#include <string>

#include "uart.h"
#include "vtk_protocol.h"
#include "general_functions.h"
#include "payments.h"
#include "energy_calculation.h"
